#---------------STEVEN TASK----------------------
#----------------2/11/2024-----------------------
#------------PEER-DOWNLOADING--------------------
#
#
# REFERENCES: https://markuseliasson.se/article/bittorrent-in-python/

#TODO: Step 1: Connecting peer from the tracker list
#TODO: Step 2: Start the TCP connection with peers
#TODO: Step 3: Send the required block with request queue
#TODO: Step 4: Follow the Blocks State and avoid the duplicated requirements
#TODO: Step 5: Send the "have" notification after finishing a piece
#TODO: Step 6: Choose the RAREST FIRST
#TODO: Step 7: Use DHT
#TODO: Step 8: Check and finish

#
#
#
#

class peerDownload:
    def __init__(self):
        print("IMPLEMENTATION")
        
        
    def contact_tracker(self):
        
        # Connect to the tracker
        print('We are trying to connect to the Tracker...')
        
        ####self.tracker_list = 
        
    def __get_list_peers__(self):
        print('IMPLEMENTATION')
        
    def __download__(self):
        print('IMPLEMENTATION')
        
    
        





