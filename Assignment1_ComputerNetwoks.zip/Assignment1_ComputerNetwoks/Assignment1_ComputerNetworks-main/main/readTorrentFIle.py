##------------READ TORRENT FILE-----------------
##------------IMPLEMENTED BY QUAN---------------
##------------DATE: 2020/11/11-------------------
#
#
#
#REFERENCES: https://markuseliasson.se/article/bittorrent-in-python/

class readTorrentFile():
    def __init__(self):
        print('IMPLEMENTATION OF READ TORRENT FILE')
        
    def get_data(self):
        print('IMPLEMENT')